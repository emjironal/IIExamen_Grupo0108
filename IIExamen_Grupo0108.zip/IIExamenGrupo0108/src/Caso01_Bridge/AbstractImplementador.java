/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Caso01_Bridge;

/**
 *
 * @author Nicole
 */
public abstract class AbstractImplementador {
    
    protected FIStream fileInputStream;
}
